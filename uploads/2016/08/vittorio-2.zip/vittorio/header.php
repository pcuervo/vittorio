<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Vittorio</title>
		<!--Import Google Icon Font-->
		<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<!--Import materialize.css-->
		<link type="text/css" rel="stylesheet" href="<?php echo THEMEPATH; ?>style.css"  media="screen,projection"/>
		<!--Typekit-->
		<script src="https://use.typekit.net/goc3dbh.js"></script>
		<script>try{Typekit.load({ async: true });}catch(e){}</script>
		<!--Let browser know website is optimized for mobile-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	</head>
	<body>

		<header>
			<nav>
				<div class="[ nav-wrapper ][ container ]">
					<a href="#" class="[ brand-logo ]"><img class="[ middle ]" src="img/logo.png" alt="Vittorio Forti Logo"></a>
					<ul id="nav-mobile" class="[ right hide-on-med-and-down ][ text-uppercase ]">
						<li><a href="http://www.tiendasvittorioforti.com">Ir al sitio</a></li>
						<li><a href="#">Haz una cita</a></li>
						<li><a href="whatsapp://send?abid=username&text=HeyThere!"><img class="[ middle	]" src="img/whatsapp-icon.png" alt="Whats app icon"></a></li>
						<li><a href="tel:+55000000">55-00-00-00</a></li>
					</ul>
				</div>
			</nav>
		</header>