	<?php global $result; ?>
		<footer class="[ page-footer ]">
			<div class="[ container ]">
			<div class="[ row ]">
				<div class="[ col s12 m3 offset-l5 l2 ]">
					<ul>
						<li><a class="[ text-uppercase ][ grey-text text-lighten-3 ]" href="#!">Compra en línea</a></li>
					</ul>
				</div>
				<div class="[ col s12 m3 l2 ]">
					<ul>
						<li><a class="[ text-uppercase ][ grey-text text-lighten-3 ]" href="#!">Vittorio Forti</a></li>
					</ul>
				</div>
				<div class="[ col s12 m6 l3 ][ text-center ]">
					<a class="[ margin-xsmall ][ inline-flex ]" href=""><img src="img/shopify-icon.png" alt="shopify icon"></a>
					<a class="[ margin-xsmall ][ inline-flex ]" href=""><img src="img/facebook-icon.png" alt="facebook icon"></a>
					<a class="[ margin-xsmall ][ inline-flex ]" href=""><img src="img/twitter-icon.png" alt="twitter icon"></a>
				</div>
			</div>
			</div>
		</footer>

		<?php wp_footer(); ?>
	</body>
</html>